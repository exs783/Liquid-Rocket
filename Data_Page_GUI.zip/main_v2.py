# libraries
import sys
import serial
import time
import os
from PyQt5.QtWidgets import QMainWindow, QGraphicsDropShadowEffect, QVBoxLayout, QApplication,QTableWidgetItem
from PyQt5.QtCore import Qt, QPoint, QTimer, QAbstractTableModel
from PyQt5.QtGui import QColor
import pyqtgraph as pg
import pandas as pd
import random
from Custom_Widgets import *

#-------------------------------------------------------------------------------------
# connect to arduino

arduino_port = "COM5"
baud = 9600
ser = serial.Serial(arduino_port,baud, timeout=0.1)
#--------------------------------------------------------------------------------------------   
         
# import ui file
from data_mainwindow import *
#----------------------------------------------------------------------------------
# Read Teensy sensor 
def read_Teensy():
    try:
        #P0 = random.randint(0,10)
        #P1 = random.randint(20,30)
        #P2 = random.randint(0,10)
        #P3 = random.randint(20,30)
        #P4 = random.randint(0,10)
        #P5 = random.randint(20,30)
        #P6 = random.randint(0,10)
        #P7 = random.randint(20,30)
        #T0 = random.randint(20,30)
        #L0 = random.randint(25,35)
        #TT = round(time.time(), 1)
        
        # vector containing all sesnsors
        #sensor_name = ['P0','P1','P2','P3','P4','P5','P6','T0','L0']
        #sensor_data = [P0,P1,P2,P3,P4,P5,P6,T0,L0]
        
        # randomely choose sensor to send
        #gen_sensor = random.randint(0,8)
        
        # crate fake teensy data packet
        #teensy_input = [sensor_name[gen_sensor], sensor_data[gen_sensor], TT]
       
        teensy_input_string = ser.readline().decode('utf-8').strip()
        teensy_input_list = teensy_input_string.split(',')
        
        if teensy_input_list == '':
            return None
        else:
            # convert data point and timestamp to floats from strings
            teensy_input_list[1] = float(teensy_input_list[1])
            teensy_input_list[2] = float(teensy_input_list[2])

            return teensy_input_list  
  
    except (UnicodeDecodeError, ValueError):
        return None                       
#----------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
# Main Window Class

class BaseWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.dragPos = QPoint()
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragPos = event.globalPos() - self.frameGeometry().topLeft()
            event.accept()
            
    def moveWindow(self, event):
        if event.buttons() == Qt.LeftButton:
            self.move(event.globalPos() - self.dragPos)
            event.accept()

class MainWindow(BaseWindow):  
    def __init__(self, parent=None):
        super().__init__(parent)  
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.stackedWidget_9.setCurrentIndex(0)
        self.setMinimumSize(850, 600)
        loadJsonStyle(self, self.ui)
        
        #------------------------------------Initialized Variables and Dataframes ----------------------------------------
        
        # initialize dictionaries to store data frames and download buttons for data files, and variab;es to plot for preview graph
        self.dataframes = {}
        self.line_colors = {}
        
        # dictionary for raw teensy data
        self.teensy_data = {}
        self.teensy_time = {}
        
        # dictionary for interpolated teensy data for live graphs
        self.teensy_time_interpolated = {}
        self.teensy_data_interpolated = {}
        
        # dictionary for plot line objectsw
        self.live_plot_lines = {}
        
        # for preview plot
        self.rounded_timestamp = []
        self.vars_to_plot = {}
        self.btn_name = {}
        
        for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
            color = self.color_gen()
            self.line_colors[button.text()] = color
            btn_name = button.text()
            self.btn_name[btn_name] = []
            
        for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
            btn_name = button.text()
            self.teensy_data[btn_name] = []
            self.teensy_time[btn_name] = []
            self.teensy_time_interpolated[btn_name] = []
            self.teensy_data_interpolated[btn_name] = []
            

        # Initialize data lists forlive data plotting and storage
        self.start_time = None
        
        # initialize graph axes
        self.tmin = 0
        self.tmax = 40
        self.pmin = 0
        self.pmax = 40
        self.xmin = 0
        self.xmax = 40
        
        # Initialize df to be plotted for preview graph
        self.current_preview_df = None
        
       #--------------------------------------------------Page Setup-------------------------------------------------
       
        # data page sizing   
        self.ui.data_files_tableWidget.setColumnWidth(0,200)
        self.ui.preview_tableView.setColumnWidth(1,150)
        
        # layout for P_graph_frame, T_graph_frame and preview frame
        if self.ui.P_graph_frame.layout() is None:
            layout = QVBoxLayout(self.ui.P_graph_frame)
            layout.setContentsMargins(0, 0, 0, 0)
            
        if self.ui.T_graph_frame.layout() is None:
            layout = QVBoxLayout(self.ui.T_graph_frame)
            layout.setContentsMargins(0, 0, 0, 0)
        
        if self.ui.preview_graphs_frame.layout() is None:
            layout = QVBoxLayout(self.ui.preview_graphs_frame)
            layout.setContentsMargins(0, 0, 0, 0)
            
        
        # Pressure plot setup
        self.plot_graph_p = pg.PlotWidget()
        self.plot_graph_p.setBackground("black")
        # Add p plot to P_graph_frame
        self.ui.P_graph_frame.layout().addWidget(self.plot_graph_p)
        
        # Temp plot setup
        self.plot_graph_T = pg.PlotWidget()
        self.plot_graph_T.setBackground("black")
        # Add T plot to frame_9
        self.ui.T_graph_frame.layout().addWidget(self.plot_graph_T)
        
        # Preview data plot setup
        styles = {"color": "black", "font-size": "15px"}
        self.plot_graph_preview = pg.PlotWidget()
        self.plot_graph_preview.setBackground("black")
        self.plot_graph_preview.setLabel("bottom", "Time (s)", **styles)
        self.plot_graph_preview.addLegend()
        self.plot_graph_preview.showGrid(x=True, y=True)
        self.plot_graph_preview.setYRange(0, 40)
        
        # Add p plot to P_graph_frame
        self.ui.preview_graphs_frame.layout().addWidget(self.plot_graph_preview)
        
        # p graph
        self.plot_graph_p.setTitle("Pressure", color="w", size="15pt")
       # self.plot_graph_p.setLabel("left", 'Pressure (psi)', **styles)
        self.plot_graph_p.setLabel("bottom", "Time (s)", **styles)
        self.plot_graph_p.addLegend()
        self.plot_graph_p.showGrid(x=True, y=True)
        self.plot_graph_p.setYRange(self.pmin, self.pmax)
        
        
        # T graph
        self.plot_graph_T.setTitle("Temp", color="w", size="15pt")
        self.plot_graph_T.setLabel("left", "Temp (C)", **styles)
        self.plot_graph_T.setLabel("bottom", "Time (s)", **styles)
        self.plot_graph_T.addLegend()
        self.plot_graph_T.showGrid(x=True, y=True)
        self.plot_graph_T.setYRange(self.tmin, self.tmax)
        
        
       # --------------------------------------------Define Button Clicks------------------------------------------------------------------------------------------------------------ 
        # push buttons to switch to different pages (different indices of stackedWidget)
        self.ui.data_files_btn.clicked.connect(self.data_files_page)
        self.ui.live_graphs_btn.clicked.connect(self.live_graphs_page)
        
        # check buttons for live graph and data collection
        self.ui.graph_check_btn.clicked.connect(self.start_graph)
        self.ui.data_check_btn.clicked.connect(self.start_data_collection)
        
        # live graph axes
        self.ui.pmin.editingFinished.connect(self.update_p_min)
        self.ui.pmax.editingFinished.connect(self.update_p_max)
        self.ui.tmin.editingFinished.connect(self.update_t_min)
        self.ui.tmax.editingFinished.connect(self.update_t_max)
        self.ui.xmin.editingFinished.connect(self.update_x_max)
        self.ui.xmax.editingFinished.connect(self.update_x_min)
        
        # download graph button
        self.ui.graph_download_btn.clicked.connect(self.download_graph)
        
        # Preview data buttons
        self.ui.data_files_tableWidget.cellPressed.connect(self.on_cell_clicked) #preview data table button
        self.ui.pre_P_btn.toggled.connect(self.on_preview_toggled) # radio button for preview graph
        
        # sensor toggle
        for button in self.ui.pre_sensor_btns_box.findChildren(QtWidgets.QCheckBox):
            button.toggled.connect(self.on_preview_toggled)
        
        for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
            button.toggled.connect(self.start_graph)
        
        # ------------------------------------------Button Functions ----------------------------------------------------------------------------------
    # Define data files page pushbutton
    def data_files_page(self):
        self.ui.stackedWidget_9.setCurrentIndex(1)
    # Define live graph page push button
    def live_graphs_page(self):
        self.ui.stackedWidget_9.setCurrentIndex(0)
    
    # start data collection function
    def start_data_collection(self):
        
        # start timer
        self.start_time = time.perf_counter() #live graph time list
        self.timer = QTimer()
        self.timer.timeout.connect(self.on_timer)
        self.timer.start(10) # update every 0.1s

        if self.ui.data_check_btn.isChecked():
            # clear graph
            self.plot_graph_p.clear()
            self.plot_graph_T.clear()
            
            
            # sensor name stored in first index, new data point value is stored in second index
            new_read = read_Teensy()
            if not new_read:           
                new_read = [None, 0.0, 0.0]
                
            sensor_name = new_read[0]
            new_value = new_read[1]
            new_timestamp = new_read[2] 
            rounded_timestamp = round(time.perf_counter() - self.start_time, 2)
            self.rounded_timestamp.append(rounded_timestamp)
            

            for i, button in enumerate(self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox)):
                btn_name = button.text()
                if btn_name == sensor_name:
                    self.teensy_data[btn_name].append(new_value)
                    self.teensy_time[btn_name].append(new_timestamp)

        
        else: # should be able to condense this dictionary logic, check later
           # store df the collect data button is unchecked and there is any data in the df
           if not self.ui.data_check_btn.isChecked() and len(self.rounded_timestamp) >= 2:
               
    
                raw_longest_sensor, raw_max_list = max(self.teensy_data.items(), key=lambda x: len(x[1]))
                int_longest_sensor, int_max_list = max(self.teensy_data_interpolated.items(), key=lambda x: len(x[1]))
                
                raw_max_len = len(raw_max_list)
                int_max_len = len(int_max_list)
                
                raw_sensor_time_list = self.teensy_time_interpolated[raw_longest_sensor].copy()
                # create data csv filename based on time the data collection ended
                int_all_sensor_data = {'Time': self.teensy_time_interpolated[int_longest_sensor]}
                
                for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
                    btn_name = button.text()
                    
                    # Adjust raw_sensor_time_list to match raw_max_len ONCE (outside the loop)
                    while len(raw_sensor_time_list) > raw_max_len:
                        raw_sensor_time_list.pop()

                    while len(raw_sensor_time_list) < raw_max_len:
                        
                        last_timestamp = raw_sensor_time_list[-1]
                        raw_sensor_time_list.append(last_timestamp + 0.1)

                    # Adjust rounded_timestamp to match raw_max_len
                    while len(self.rounded_timestamp) < raw_max_len:
                        self.rounded_timestamp.append(self.rounded_timestamp[-1])
                        
                    int_all_sensor_data[btn_name] = self.teensy_data_interpolated[btn_name]
                    

                for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
                    btn_name = button.text()
    
                # Pad raw data to match longest sensor
                    while len(self.teensy_data[btn_name]) < raw_max_len:
                        self.teensy_data[btn_name].append(0.0)
    
                # Pad interpolated data to match longest interpolated sensor
                    while len(self.teensy_data_interpolated[btn_name]) < int_max_len:
                        self.teensy_data_interpolated[btn_name].append(0.0)    
                    
                    # Add to interpolated data dictionary
                    int_all_sensor_data[btn_name] = self.teensy_data_interpolated[btn_name]

                # Create raw data dictionary 
                raw = {**self.teensy_data, 'Time': raw_sensor_time_list}

                # Create DataFrame
                int_output_df = pd.DataFrame(int_all_sensor_data)
                
                int_output_df = pd.DataFrame(int_all_sensor_data)
                raw_output_df = pd.DataFrame(raw)#, columns=)
                curr_time = time.strftime("%H:%M:%S", time.localtime())
                
                filename = 'Int_' + str(curr_time) + '.csv'
                filename_valid = filename.replace(':', '-')
                
                filename_raw = 'Raw_' + str(curr_time) + '.csv'
                filename_valid_raw = filename_raw.replace(':', '-')
                
                # add to dataframes and download buttons dictionaries
                self.dataframes[filename_valid] = int_output_df
                self.dataframes[filename_valid_raw] = raw_output_df
                
            # Check if file has already been created
                file_already_exists = False
                for row in range(self.ui.data_files_tableWidget.rowCount()):
                    item = self.ui.data_files_tableWidget.item(row, 1)
                    if item and item.text() == filename_valid:
                        file_already_exists = True
                        break
                
                # if file does not exist, add to next available slot in table
                if not file_already_exists:
                    for i in range(11):
                        it = self.ui.data_files_tableWidget.item(i, 0)
                        if it and it.text():
                            i = i + 1
                        else:
                            self.ui.data_files_tableWidget.setItem(i , 0, QtWidgets.QTableWidgetItem(filename_valid))
                            self.dataframes[filename_valid].to_csv(filename_valid, index=False)
                            self.dataframes[filename_valid_raw].to_csv(filename_valid_raw, index=False)
                            break
                
                # clear dictionaries for live graph data
                self.rounded_timestamp = []
                
                for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
                    btn_name = button.text()
                    self.teensy_data[btn_name] = []
                    self.teensy_time[btn_name] = []
                    self.teensy_time_interpolated[btn_name] = []
                    self.teensy_data_interpolated[btn_name] = []
                    
                    

                
    # preview selected file in preview table           
    def on_cell_clicked(self, row, column):
        if column == 0:
            cell_item = self.ui.data_files_tableWidget.item(row, column)
            if cell_item:
                df_name = cell_item.text()
                df = self.dataframes[df_name]
                if df is not None:
                    model = pandasModel(df)
                    self.current_preview_df = df
                    self.on_preview_toggled()
                    self.ui.preview_tableView.setModel(model)
        
        
    # display preview graph data if a cell has been selected
    def on_preview_toggled(self):
        if self.current_preview_df is not None:
            self.plot_preview()
    
    # preview plot function
    def plot_preview(self):
        # clear graph    
        self.plot_graph_preview.clear()
        
        for button in self.ui.pre_sensor_btns_box.findChildren(QtWidgets.QCheckBox):
            
            
            if button.isChecked():
                # variable to graph
                var_to_plot = self.current_preview_df[button.objectName()]
                # pen color for each sensor
                color = self.line_colors[button.objectName()]
                pen = pg.mkPen(color=color)
        # plot pressure or temp based on wether pre_P_btn or pre_T_btn is checked
                if self.ui.pre_P_btn.isChecked(): 
                    styles = {"color": "black", "font-size": "15px"}      
                    self.plot_graph_preview.setTitle("Pressure", color="w", size="15pt")
                    self.plot_graph_preview.getAxis('left').setLabel("Pressure (psi)", **styles)
                    
                    # only plot pressure values if temp redio btn is ticked
                    if 'T' in button.text():
                        var_to_plot = None
            
                elif self.ui.pre_T_btn.isChecked():
                    styles = {"color": "black", "font-size": "15px"}
                    self.plot_graph_preview.setTitle("Temp", color="w", size="15pt")
                    self.plot_graph_preview.setLabel("left", "Temp (C)", **styles)
                    
                    # only plot temp values if temp redio btn is ticked
                    if 'P' in button.text():
                        var_to_plot = None
            else:
                var_to_plot = None

            if var_to_plot is not None:
                
                Time = self.current_preview_df['Time']
                
                self.line = self.plot_graph_preview.plot(
                    Time,
                    var_to_plot,
                    name= f"{var_to_plot.name}",
                    pen=pen,
                    #symbol="+",
                    #symbolSize=10,
                    #symbolBrush="w",
                    )
            elif not button.isChecked():
                pass
                
           
#----------------------------------------------------------Update Functions----------------------------------------------------           
    # function to update live graph       
    def update_df(self):
        
        # sensor name stored in first index, new data point value is stored in second index
        new_read = read_Teensy()
        if not new_read:          # covers None or empty list
            new_read = [None, 0.0, 0.0]
        sensor_name = new_read[0]
        new_value = new_read[1]
        new_timestamp = new_read[2]
        
        # round new timestamp to nearest 10th second
        rounded_timestamp = round(time.perf_counter() - self.start_time, 2)
        self.rounded_timestamp.append(rounded_timestamp)

        if new_value != "":  
            try:
                all_btns = self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox)
                
                for button in all_btns:
                    btn_name = button.text()
                    
                    if btn_name == sensor_name:
                        self.teensy_data[btn_name].append(new_value)
                        self.teensy_time[btn_name].append(new_timestamp)
                        self.teensy_data_interpolated[btn_name].append(float(new_value))
                        self.teensy_time_interpolated[btn_name].append(rounded_timestamp)
                        
                    elif btn_name != sensor_name:
                        if not self.teensy_time_interpolated[btn_name]:
                            self.teensy_data_interpolated[btn_name].append(float(0.0))
                            self.teensy_time_interpolated[btn_name].append(rounded_timestamp)
                        
                        elif len(self.teensy_time_interpolated[btn_name]) > 0:
                        
                            if self.teensy_time_interpolated[btn_name][-1] != rounded_timestamp:
                        
                                # keep using the last known value for a sensor until a new one is recieved
                                if not self.teensy_data[btn_name]:
                                    placeholder_value = 0.0
                                else:
                                    placeholder_value = self.teensy_data[btn_name][-1]
                                
                                self.teensy_data_interpolated[btn_name].append(float(placeholder_value))
                                self.teensy_time_interpolated[btn_name].append(rounded_timestamp)
                            
                
            except ValueError:
                return
        

        
            
        
    # Define live graph button function
    def start_graph(self):
        
        #Clear plots
        self.plot_graph_p.clear()
        self.plot_graph_T.clear()
         
        if self.ui.graph_check_btn.isChecked():
            
                    
            for i, button in enumerate(self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox)):
                if button.isChecked():
                
                # variable to graph
                    btn_name = button.text()
                    var_to_plot = self.teensy_data_interpolated[btn_name]#[:min_value]
                    
                    # pen color for each sensor
                    color = self.line_colors[btn_name]
                    pen = pg.mkPen(color=color)

                    
                    if btn_name == 'T0': #would not want to hardcode this if there is more than one thermocouple
                        plot_item = self.plot_graph_T.plot(
                                self.teensy_time_interpolated[btn_name],
                                var_to_plot,
                                name=btn_name,
                                pen=pen,
                                #symbol="+",
                                #symbolSize=10,
                                #symbolBrush="w",
                            )
                        self.live_plot_lines[btn_name] = plot_item
                    else:
                        plot_item = self.plot_graph_p.plot(
                                self.teensy_time_interpolated[btn_name],
                                var_to_plot,
                                name=btn_name,
                                pen=pen,
                                #symbol="+",
                                #symbolSize=10,
                                #symbolBrush="w",
                            )
                        self.live_plot_lines[btn_name] = plot_item
           
        else:
            pass
        
        
        
    
        # only run update functions when toggles are checked
    def on_timer(self):
        if self.ui.graph_check_btn.isChecked():
            self.update_plot()         

        if self.ui.data_check_btn.isChecked():
            self.update_df()  
             
    
        self.show()

    # update plot 
    def update_plot(self):
            
        # add to graph
        for button in self.ui.livesensor_btns_box.findChildren(QtWidgets.QCheckBox):
            if button.isChecked():
                btn_name = button.text()
                line_object = self.live_plot_lines[btn_name]#[:min_value] 
                line_object.setData(self.teensy_time_interpolated[btn_name], self.teensy_data_interpolated[btn_name])
    
    
    # Update Graph axes to match spinbox inputs         
    def update_x_min(self):
       self.xmin = self.ui.xmin.value()
       self.plot_graph_p.setXRange(self.xmin, self.xmax)
       self.plot_graph_T.setXRange(self.xmin, self.xmax)
    def update_x_max(self):
       self.xmax = self.ui.xmax.value()
       self.plot_graph_p.setXRange(self.xmin, self.xmax)
       self.plot_graph_T.setXRange(self.xmin, self.xmax)
    def update_p_min(self):
       self.pmin = self.ui.pmin.value()
       self.plot_graph_p.setYRange(self.pmin, self.pmax)
    def update_p_max(self):
       self.pmax = self.ui.pmax.value()
       self.plot_graph_p.setYRange(self.pmin, self.pmax)
    def update_t_min(self):
       self.tmin = self.ui.tmin.value()
       self.plot_graph_T.setYRange(self.tmin, self.tmax)
    def update_t_max(self):
       self.tmax = self.ui.tmax.value()
       self.plot_graph_T.setYRange(self.tmin, self.tmax)
   
   #----------------------------------------------------Miscellaneous Functions-------------------------------------------------------    
    # download graph function
    def download_graph(self):
        pic_time = time.strftime("%H:%M:%S", time.localtime())
        
        image1 = self.plot_graph_p.grab(self.plot_graph_p.rect()) #returns QPixMap
        image2 = self.plot_graph_T.grab(self.plot_graph_p.rect())
        
        # name filenames with time pic was taken
        p_filename = 'Pressure_' + str(pic_time) + '.png'
        p_filename_valid = p_filename.replace(':', '-')
        
        p_filename = 'Temperature_' + str(pic_time) + '.png'
        t_filename_valid = p_filename.replace(':', '-')
        
        # save images
        image1.save(p_filename_valid) #file name/path and image type here
        image2.save(t_filename_valid)
        
    # generate new line colors for each sensor on graph    
    def color_gen(self):
        
        r = random.randint(0,255)
        b = random.randint(0,255)
        g = random.randint(0,255)
        
        if (r != b) & (b != g) & (r != g):
            rbg = (r,b,g)
            return rbg
        else:
            pass
        
        
 #-------------------------------------------------------Classes----------------------------------------------------------------
    
# Class to convert pandas df into format that PyQt tableView can display    
class pandasModel(QAbstractTableModel):
    
    def __init__(self, data, parent=None):
        super().__init__()
        self._data = data
    
    def rowCount(self, parent=None):
        return self._data.shape[0]
    def columnCount(self, parent=None):
        return self._data.shape[1]
    
    def data(self, index, role=Qt.DisplayRole):
        if index.isValid():
            if role == Qt.DisplayRole:
                return str(self._data.iloc[index.row(), index.column()])
        return None
       
    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self._data.columns[col]
        return None
#--------------------------------------------------------------------------------------------------------------------------------

        
# Execute App
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
